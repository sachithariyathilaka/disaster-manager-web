print("Medical Emergancy: 0.8974")
print("Rescures: 0.0745")
print("Resource Allocation: 0.0128")
print("Sanitization: 0.0100")
